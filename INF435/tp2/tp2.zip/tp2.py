#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

## ----------------------------------
## TP2 
## ----------------------------------

import graphviz

## ----------------------------------
## global variables and data structure





## ----------------------------------
## --- GRAPH CONSTRUCTION ---

##
## vertex creation

def createVertex(id):
    """insert the vertex in your data structure"""
    
    print id

##
## edge creation

def createEdge(node1, node2, value):
    """insert the edge linking two vertices 'node1' and 'node2' in your data structure
    
    don't forget to add the 'friendship value' !!!
    """

    print node1, "<---"+value+"--->", node2

## ----------------------------------
## --- PART  "Diffusion" ---
##
## create the cheapest broadcast tree


def cheapestTree(node="Babet"):
    """return the 'overall friendship cost' and the set of edges
    
    result is (an integer, a list of pair of nodes)
    """    
    
    return (0, [])
    
## ----------------------------------
## --- PART  "Diffusion paths" ---
##
## create all the possible path to any node from any node


def diffusionPaths(tree):
    """return for each "source_target" the sequence of nodes composing the path
    
    result is a dictionnary {'Mabeuf_Cosette': ['Mabeuf', 'Marius', 'LtGillenormand', 'Cosette'], 'Mabeuf_Valjean': ['Mabeuf',...,'Valjean'], ...}
    """    
    
    return {}


## ----------------------------------
## --- PART "Optimisation" ---
##
## find the better root

def bestRoot(tree):
    """return the node so that the tree depth is minimal
    
    'tree' is a list of pair of nodes
    """
    
    return ""
    

    
## ----------------------------------
## ----------------------------------
## ----------------------------------
## --- MAIN ---

    
fileGraph = open("promotion.graph", 'r')
for line in fileGraph:
    
    lineContent = line.split(" ")

    ## retrieve id from file and create vertex
    if "id" in lineContent:
        ident = lineContent[1][:-1]
        createVertex(ident)
        
    ## retrieve two ids and a value from file and create edge between them
    if "edge" in lineContent:
        id1 = lineContent[1]
        id2 = lineContent[2]
        weight = lineContent[3][:-1]
        createEdge(id1, id2, weight) ## This crerateEdge is empty !!!!!!

## test the PART  "Diffusion"
res = cheapestTree()
graphviz.showcheapestTree(res) # show the tree: blue edges
print
print "The 'overall cost' is", res[0]
print "Here is the set of communication links to create: "
for edge in res[1]:
    print str(edge[0])+" --- "+str(edge[1])
    
## Store all the possible paths from any source to any target
## The expected Gpath could be this way:
## Gpath = {'Mabeuf_Cosette': ['Mabeuf', 'Marius', 'LtGillenormand', 'Cosette'], 'Mabeuf_Valjean': ['Mabeuf',...,'Valjean'], ...}
Gpath=diffusionPaths(res[1])
if 'Mabeuf_Cosette' in Gpath.keys():
	print
	print "The path Mabeuf -> Cosette is ", Gpath['Mabeuf_Cosette']

    
## test the PART "Optimisation"
print
print "The best root is", bestRoot(res[1])


