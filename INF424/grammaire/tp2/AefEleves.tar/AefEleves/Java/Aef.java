
public abstract class Aef {
	public abstract boolean accepte(String input);

}
