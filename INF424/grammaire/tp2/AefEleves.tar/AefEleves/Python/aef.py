class Aef:
    pass

class Aef1(Aef):
    def accepte(self, text):
        etat = 1

        for char in text:
            # Traitement des characteres de la chaine
            if etat == 1 and char == "a":
                etat = 2
            elif etat ==2 and char == "b":
                etat = 1
            else:
                # Il n'y a pas de transition correspondante
                return False

        # il n'y a plus rien a lire. Est-on dans un etat terminal?
        if etat == 2:
            return True
        else:
            return False

if __name__ == "__main__":
    aef = Aef1()
    while True:
        print "Veuillez entrer votre chaine de test"
        text = raw_input()
        if aef.accepte(text):
            print "Chaine %s acceptee" % text
        else:
            print "Chaine %s refusee" % text
